function [c_matrix,Result,RefereceResult]= confusionmat(actual,predict,Display)

%%
%Condition Check
if (nargin < 2)
    error('Not enough input arguments. Need atleast two vectors as input');
elseif (nargin == 2)
    Display=1;
elseif (nargin > 3)
    error('Too many input arguments.');
end
actual=actual(:);
predict=predict(:);
if length(actual) ~= length(predict)
    error('Input have different lengths')
end
un_actual=unique(actual);
un_predict=unique(predict);
condition=length(un_actual)==length(un_predict);

if ~condition
    error('Class List is not same in given inputs')
end
condition=(sum(un_actual==un_predict)==length(un_actual));
if ~condition
    error('Class List in given inputs are different')
end

%%
%Start process
%Build Confusion matrix
%Set variables
class_list=un_actual;
disp('Class List in given sample')
disp(class_list)
fprintf('\nTotal Instance = %d\n',length(actual));
n_class=length(un_actual);
c_matrix=zeros(n_class);
predict_class=cell(1,n_class);
class_ref=cell(n_class,1);
row_name=cell(1,n_class);
%Calculate conufsion for all classes
for i=1:n_class
    class_ref{i,1}=strcat('class',num2str(i),'==>',num2str(class_list(i)));
    for j=1:n_class
        val=(actual==class_list(i)) & (predict==class_list(j));
        c_matrix(i,j)=sum(val);
        predict_class{i,j}=sum(val);
    end
    row_name{i}=strcat('Actual_class',num2str(i));
    disp(class_ref{i})
end

c_matrix_table=cell2table(predict_class);
c_matrix_table.Properties.RowNames=row_name;
disp('Confusion Matrix')
disp(c_matrix_table)


%%
%start calculate
switch n_class
    case 2
        TN=c_matrix(1,1);
        FP=c_matrix(1,2);
        FN=c_matrix(2,1);
        TP=c_matrix(2,2);
        
    otherwise
        TP=zeros(1,n_class);
        FN=zeros(1,n_class);
        FP=zeros(1,n_class);
        TN=zeros(1,n_class);
        for i=1:n_class
            TP(i)=c_matrix(i,i);
            FN(i)=sum(c_matrix(i,:))-c_matrix(i,i);
            FP(i)=sum(c_matrix(:,i))-c_matrix(i,i);
            TN(i)=sum(c_matrix(:))-TP(i)-FP(i)-FN(i);
        end
        
end

P=TP+FN;
N=FP+TN;
switch n_class
    case 2
        accuracy=((TP+TN)/(P+N))*100;
        Result.Accuracy=(accuracy);
    otherwise
        accuracy=((TP)./(P+N))*100;
        Result.Accuracy=sum(accuracy);
end
Recall=(TP./P)*100;
Precision=(TP./(TP+FP))*100;
F1_score=( (2*(Recall.*Precision) ) ./ (Precision+Recall) );

%%
%Output Struct for individual Classes
RefereceResult.Class=class_ref;
RefereceResult.Accuracy=accuracy';
RefereceResult.Recall=Recall';
RefereceResult.Precision=Precision';
RefereceResult.F1_score=F1_score';


%Output Struct for over all class lists
Result.Recall=mean(Recall);
Result.Precision=mean(Precision);
Result.F1_score=mean(F1_score);

%%
%Diplay
% Display=1;
if Display
    
    if n_class>2
        disp('Multi-Class Confusion Matrix Output')
        TruePositive=TP';
        FalsePositive=FP';
        FalseNegative=FN';
        TrueNegative=TN';
        TFPN=table(TruePositive,FalsePositive,FalseNegative,TrueNegative,...
            'RowNames',row_name);
        disp(TFPN);
        Param=struct2table(RefereceResult);
        disp(Param)
    else
        disp('Two-Class Confution Matrix')
        param={'','TruePositive','FalsePositive';...
            'FalseNegative',c_matrix(1,1),c_matrix(1,2);...
            'TrueNegative',c_matrix(2,1),c_matrix(2,2)};
        disp(param)
        
    end
    disp('Over all valuses (%)')
    disp(Result)
    
end

RefereceResult.TruePositive=TP';
RefereceResult.FalsePositive=FP';
RefereceResult.FalseNegative=FN';
RefereceResult.TrueNegative=TN';
