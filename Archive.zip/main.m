Im=uigetfile({'*.jpg';'*.png'},'fileselector');
Im=imread(Im);

ground=uigetfile('*.mat');
ground = load(ground);

f = figure('Name','segmentasi Retakan jalan Apal',...
    'NumberTitle','off','Position',[250 130 900 600]);

tgroup1 = uitabgroup('Parent', f);
tab1 = uitab('Parent', tgroup1, 'Title', 'RGB');
tab2 = uitab('Parent', tgroup1, 'Title', 'Grayscale');
tab3 = uitab('Parent', tgroup1, 'Title', 'Sobel');
tab4 = uitab('Parent', tgroup1, 'Title', 'Hasil Segmentasi');
tab5 = uitab('Parent', tgroup1, 'Title', 'Deteksi');

panel1 = uipanel('Parent',tab1,'Title','Citra Asli','FontWeight','bold',...
    'FontSize',10,'Position',[.28 .5 .45 .5]);

tgroup2 = uitabgroup('Parent', tab1,'Position',[.06 .05 .85 .44]);
tabRed = uitab('Parent', tgroup2, 'Title', 'Red');
tabGreen = uitab('Parent', tgroup2, 'Title', 'Green');
tabBlue = uitab('Parent', tgroup2, 'Title', 'Blue');

ax1 = axes('Parent',panel1,'Position',[.05 .05 .9 .9],'XTick',[],...
    'YTick',[]);

%Img = imread('peppers.png');
axes(ax1)
imshow(Im)

ax2 = axes('Parent',tabRed,'Position',[.02 .04 .48 .9],'XTick',[],...
    'YTick',[]);

ax3 = axes('Parent',tabRed,'Position',[.62 .12 .34 .74],'XTick',[],...
    'YTick',[]);

ax4 = axes('Parent',tabGreen,'Position',[.02 .04 .48 .9],'XTick',[],...
    'YTick',[]);

ax5 = axes('Parent',tabGreen,'Position',[.62 .12 .34 .74],'XTick',[],...
    'YTick',[]);

ax6 = axes('Parent',tabBlue,'Position',[.02 .04 .48 .9],'XTick',[],...
    'YTick',[]);

ax7 = axes('Parent',tabBlue,'Position',[.62 .12 .34 .74],'XTick',[],...
    'YTick',[]);

R = Im(:,:,1);
G = Im(:,:,2);
B = Im(:,:,3);

Red = cat(3,R,G*0,B*0);
Green = cat(3,R*0,G,B*0);
Blue = cat(3,R*0,G*0,B);

rmap = zeros(256,3);
rmap(:,1) = 0:255;
rmap = rmap/255;

gmap = zeros(256,3);
gmap(:,2) = 0:255;
gmap = gmap/255;

bmap = zeros(256,3);
bmap(:,3) = 0:255;
bmap = bmap/255;

axes(ax2)
imshow(Red), colormap(ax2,rmap), colorbar

axes(ax3)
histogram(R(:),256,'FaceColor','r','EdgeColor','r')
set(gca,'XLim',[0 255])
set(gca,'YLim',[0 15000])
grid on

axes(ax4)
imshow(Green), colormap(ax4,gmap), colorbar

axes(ax5)
histogram(G(:),256,'FaceColor','g','EdgeColor','g')
set(gca,'XLim',[0 255])
set(gca,'YLim',[0 15000])
grid on

axes(ax6)
imshow(Blue), colormap(ax6,bmap), colorbar

axes(ax7)
histogram(B(:),256,'FaceColor','b','EdgeColor','b')
set(gca,'XLim',[0 255])
set(gca,'YLim',[0 15000])
grid on


panel2 = uipanel('Parent',tab2,'Title','RGB Image','FontWeight','bold',...
    'FontSize',10,'Position',[.03 .3 .25 .4]);

ax8 = axes('Parent',panel2,'Position',[.05 .05 .9 .9],'XTick',[],...
    'YTick',[]);

axes(ax8)
imshow(Im)


%% Grayscale
panel3 = uipanel('Parent',tab2,'Title','Grayscale Image','FontWeight','bold',...
    'FontSize',10,'Position',[.32 .3 .65 .4]);

ax9 = axes('Parent',panel3,'Position',[.02 .064 .48 .9],'XTick',[],...
    'YTick',[]);

ax10 = axes('Parent',panel3,'Position',[.618 .132 .34 .775],'XTick',[],...
    'YTick',[]);

Gray=uint8(zeros(size(Im,1),size(Im,2)));
for i=1:size(Im,1)
      for j=1:size(Im,2)
          Gray(i,j)=0.2989*Im(i,j,1)+0.5870*Im(i,j,2)+0.1140*Im(i,j,3);
      end
end
axes(ax9)
imshow(Gray), colormap(ax9, gray), colorbar

axes(ax10)
histogram(Gray(:),256,'FaceColor',[.64 .64 .64],'EdgeColor',[.64 .64 .64])
set(gca,'XLim',[0 255])
set(gca,'YLim',[0 15000])
grid on

%0.2989 * R + 0.5870 * G + 0.1140 * B 
  
%subplot(2,2,2)
%imshow(Gray);
%title('Grayscale Image');
%%
%Gray = double(Gray);
MGray = medfilt2(Gray, [3 3]);

panel5 = uipanel('Parent',tab3,'Title','Sobel Image','FontWeight','bold',...
    'FontSize',10,'Position',[.28 .5 .45 .5]);

panel7 = uipanel('Parent',tab3,'Title','Histogram Sobel Image','FontWeight','bold',...
    'FontSize',10,'Position',[.06 .05 .85 .44]);

ax12 = axes('Parent',panel5,'Position',[.05 .05 .9 .9],'XTick',[],...
    'YTick',[]);

ax13 = axes('Parent',panel7,'Position',[.05 .05 .9 .9],'XTick',[],...
    'YTick',[]);

%% sobel 
[m, n] = size(MGray);

F=double(MGray);
G=zeros(m,n);
for y=2 : m-1
    for x=2 : n-1
        G(y, x) = sqrt(...
             ((F(y-1,x-1)+(F(y-1,x))+F(y-1,x+1) + (- ...
             F(y+1,x-1)-(2*F(y+1,x))-F(y+1,x+1)))^2)) + ...
             sqrt((F(y-1,x-1)+(F(y,x-1))+F(y+1,x-1)+ (- ...
             F(y-1,x+1)-(2*F(y,x+1))-F(y+1,x+1)))^2) ;
    end
end

G = uint8(G);
axes(ax12)
imshow(G), colorbar('Ticks',[0,1])
axes(ax13)
imhist(G)
grid on

%subplot(2,2,3)
%imshow(G);
%title('Sobel Image');

%% median filter

G2 = double(G);
[r,c]=size(G2);
F2=zeros(r,c);
for i=2:r-1
    for j=2:c-1
        flt=[G2(i-1,j-1),G2(i-1,j),G2(i-1,j+1),...
            G2(i,j-1),G2(i,j),G2(i,j+1),G2(i+1,j-1),...
            G2(i+1,j),G2(i+1,j+1)];
F2(i,j)=median(flt);
    end
end

F2=uint8(F2);

figure('Name','Penerapan Median Filter','NumberTitle','off')...
    , imshow(F2), title('Median Filtering')

%% otsu perhitungan
[m, n] = size(F2);
jum_piksel = m * n;

% Kosongkan histogram
for i=1 : 256
    h(i) = 0;
end

% Hitung histogram
for i=1 : m
    for j=1 : n
        intensitas = F(i,j);
        h(intensitas+1) = h(intensitas+1) + 1;
    end
end

% Hitung p(i)
for i=1 : 256
    p(i) = h(i) / jum_piksel;
end

% Hitung rata-rata total
mT = 0;
for i=1 : 256
    mT = mT + i * p(i);
end

% Hitung t optimal
ambang = 0;
varMaks = 0;
for t=0 : 255
    % Hitung w1(t)
    w1 = 0.0;
    for i=1 : t
        w1 = w1 + p(i+1);
    end
    
    % Hitung w2(t)
    w2 = 0.0;
    for i=t+1 : 255
        w2 = w2 + p(i+1);
    end
    
    % Hitung m1
    m1 = 0;
    for i=0 : t
        if w1 > 0
           m1 = m1 + i * p(i+1)/w1;
        end
    end
    
    % Hitung m2
    m2 = 0;
    for i=t+1 : 255
        if w2 > 0
           m2 = m2 + i * p(i+1)/w2;
        end
    end
    
    % Hitung BCV
    bcv = (w1 * ((m1 - mT)^2)) + (w2 * ((m2 - mT)^2));
   
    if bcv > varMaks
        varMaks = bcv;
        ambang  = t;
    end
end

panel6 = uipanel('Parent',tab4,'Title','Hasil Segmentasi','FontWeight','bold',...
    'FontSize',10,'Position',[.17 .3 .65 .6]);

ax15 = axes('Parent',panel6,'Position',[.07 .064 .9 .9],'XTick',[],...
    'YTick',[]);

    %ambangX = otsu(F2);
    [m,n]=size(F2);
        ambangZ=zeros(m,n);
        for i=2:m-1
            for j=2:n-1
               if F2(i,j)<ambang+50
                 ambangZ(i,j)=1;
               else
                 ambangZ(i,j)=0;
               end
            end
        end
    
    figure('Name','Penerapan Otsu','NumberTitle','off')...
    , imshow(ambangZ), title('Otsu')
    %ambangZ = logical(mod(ambangX,2))
    %se = strel('line',4,30);
    %ambangZ = bwperim(amba ngZ,8);
    %ambangZ = imdilate(ambangZ,strel('disk',2)); %menebalkan
        %ambangZ(5:6,5:6)=1;
%% dilasi
        [m,n]=size(ambangZ);
        imageout=zeros(m,n);
        for i=2:m-1
            for j=2:n-1
                t=sum(sum(ambangZ(i-1:i+1,j-1:j+1)));
               if t>1
                 imageout(i,j)=1;
               else
                 imageout(i,j)=0;
               end
            end
        end
    imageout = bwareaopen(imageout,20); %menghapus dengan t=x
    %ambangZ = imopen(ambangZ,strel('disk',5));
    %ambangZ = bwmorph(ambangZ,'remove');
    save('imageout');
    axes(ax15)
    %ambangZ = medfilt2(ambangZ);
    %figure, imhist(ambangX), axis image off
    imagesc(imageout)
    
    colormap(gray)
    %imsave
    %title('Segmentasi Image');
    
 

 %% deteksi
 panel7 = uipanel('Parent',tab5,'Title','Deteksi Retakan','FontWeight','bold',...
    'FontSize',10,'Position',[.17 .3 .65 .6]);

ax16 = axes('Parent',panel7,'Position',[.07 .064 .9 .9],'XTick',[],...
    'YTick',[]);
bn=bwareaopen(imageout,20);
%figure,imshow(bn)
[L Ne]=bwlabel(bn);
%figure,imshow(label2rgb(L));
prop=regionprops(L);
hold on
for n=1:length(prop)
    rectangle('Position',prop(n).BoundingBox,'EdgeColor','g','LineWidth',2)
    x=prop(n).Centroid(1);
    y=prop(n).Centroid(2);
    plot(x,y,'*')
%     text(x,y,'O')
end
hold off
cla

axes(ax16)
imshow(Im)

%figure('Name','Deteksi','NumberTitle','off')...
%    , imshow(Im), title('Terdeteksi retakan')

hold on
B=bwboundaries(bn);
for k = 1:length(B)
    boundary = B{k};
    plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 2)
end
hold off

%% ground truth
bound = ground.groundTruth.Boundaries
bound2 = imdilate(bound,strel('disk',1));

% [m,n]=size(bound);
%         bound2=zeros(m,n);
%         for i=2:m-1
%             for j=2:n-1
%                 t=sum(sum(bound(i-1:i+1,j-1:j+1)));
%                if t>1
%                  bound2(i,j)=1;
%                else
%                  bound2(i,j)=0;
%                end
%             end
%         end
%seg = load('ambangZ.mat');
%predict = loaconfusionmatd('001.mat');
%seg = predict.grousijindTruth.Segmentation050
%seg = logical(mod(predict.groundTruth.Segmentation,2))
%bound = ~bound

figure('Name','Ground Truth','NumberTitle','off')...
    , imagesc(bound), title('Ground Truth'), colormap(gray)


[confMat,order] = confusionmat(imageout,bound2);